package com.example.laboratorio01.exemplotoast;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText x;
    EditText y;
    EditText z;
    Button btnCalcular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        x = findViewById(R.id.txt1);
        y = findViewById(R.id.txt2);
        z = findViewById(R.id.txt3);
        btnCalcular = findViewById(R.id.btnAcao);

        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String a = x.getText().toString();
                int ladoX = Integer.parseInt(a);

                String b = y.getText().toString();
                int ladoY = Integer.parseInt(b);

                String c = z.getText().toString();
                int ladoZ = Integer.parseInt(c);

                if (ladoX == ladoY && ladoY == ladoZ){
                    Toast.makeText(getApplicationContext(), "Triângulo Equilátero", Toast.LENGTH_LONG).show();
                } else if (ladoX == ladoY || ladoX == ladoZ || ladoY == ladoZ){
                    Toast.makeText(getApplicationContext(), "Triângulo Isóceles", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Triângulo Escaleno", Toast.LENGTH_LONG).show();
                }
            }
        });

    }
}
